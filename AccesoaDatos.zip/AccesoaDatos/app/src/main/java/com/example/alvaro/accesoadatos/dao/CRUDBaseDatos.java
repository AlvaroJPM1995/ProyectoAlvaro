package com.example.alvaro.accesoadatos.dao;

import android.support.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.example.alvaro.accesoadatos.Idao.IProductoDAO;
import com.example.alvaro.accesoadatos.Modelo.Producto;

import java.util.ArrayList;

import static com.example.alvaro.accesoadatos.MainActivity.adapter;
import static com.example.alvaro.accesoadatos.MainActivity.listaProduct;

public class CRUDBaseDatos implements IProductoDAO {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    // Realizamos la insercion de datos en la BD Firebase.
    public void insertarBD(Producto p){
        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.child("Productos").child(p.getCodigoProducto()).setValue(p);
    }

    // Creamos las sentencias necesaias para realizar una lectura de la BD Firebase.
    public void leerBD(){
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Productos");
        listaProduct.clear();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot objSnapchot : dataSnapshot.getChildren()){
                    Producto p = objSnapchot.getValue(Producto.class);
                    listaProduct.add(p);

                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    // Creamos las sentencias necesarias para actualizar los datos de la BD Firebase.
    public void actualizarBD(Producto p){
        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.child("Productos").child(p.getCodigoProducto()).setValue(p);
    }

    // Ceramos las sentencias necesarias para eliminar un registro en la BD Firebase.
    public void borrarBD(Producto p){
        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.child("Poducto").child(p.getCodigoProducto()).removeValue();
    }

}