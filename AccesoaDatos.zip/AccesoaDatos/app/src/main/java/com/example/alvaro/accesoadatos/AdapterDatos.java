package com.example.alvaro.accesoadatos;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

import com.example.alvaro.accesoadatos.Modelo.Producto;
import com.example.alvaro.accesoadatos.dao.CRUDBaseDatos;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos>{

    private final ArrayList<Producto> listaProducto;
    private LayoutInflater adapterInflater;

    public AdapterDatos(Context context, ArrayList<Producto> listaProducto) {
        adapterInflater = LayoutInflater.from(context);
        this.listaProducto = listaProducto;
    }

    // Asignamos el layout creado para nuestro Recyclerview al LayoutInflater y es en este donde vamos a visualizar todos los elementos del array.
    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View mItemView = adapterInflater.inflate(R.layout.item_list, viewGroup, false);
        return new ViewHolderDatos(mItemView, this);
    }

    // Llamamos al ViewHolder y mostramos los datos en la posicion indicada.
    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {
        viewHolderDatos.asignarDatos(listaProducto.get(i));
    }

    // Gracias a esta funcion obtenemos el tamaño del arrayList.
    @Override
    public int getItemCount() {
        return listaProducto.size();
    }

    // Creamos la clase encargada de trabaja con los datos y los textos de la activity
    public class ViewHolderDatos extends RecyclerView.ViewHolder implements View.OnClickListener{
        public TextView codigoProducto;
        public TextView nombreProducto;
        public ImageView papelera;
        AdapterDatos adapter;
        private final Context context;

        // Asociamos los items de la activity con los elementos creados en la clase, inicializamos el adapter y añadimos los metodos OnClick.
        public ViewHolderDatos(@NonNull View itemView, final AdapterDatos adapter) {
            super(itemView);
            codigoProducto = itemView.findViewById(R.id.lblCodigoProduct);
            nombreProducto = itemView.findViewById(R.id.lblNombre);
            papelera = itemView.findViewById(R.id.papelera);

            this.adapter = adapter;
            context = itemView.getContext();

            itemView.setOnClickListener(this);
            papelera.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    CRUDBaseDatos borrado = new CRUDBaseDatos();
                    borrado.borrarBD(listaProducto.get(getLayoutPosition()));
                    adapter.notifyItemRemoved(getLayoutPosition());
                }
            });
        }

        // Asigmanos los datos del objeto con los campos de texto a relenar en la activity.
        public void asignarDatos(Producto p){
            codigoProducto.setText(p.getCodigoProducto());
            nombreProducto.setText(p.getNombre());
        }

        // Esta funcion se encarga de que cuando pulsemos una de las tarjetas nos mande a una activity a parte para modifica sus datos.
        @Override
        public void onClick(View v) {
            Intent i = new Intent(context.getApplicationContext(), ModifyDatos.class);
            context.startActivity(i);
        }
    }
}
