package com.example.alvaro.accesoadatos;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import Modelo.Producto;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos> {

    List<Producto> listaProducto = new ArrayList<>();

    public AdapterDatos(List<Producto> listaProducto) {
        this.listaProducto = listaProducto;
    }

    /*
        Nos enlaza el adaptador con el archivo itemlist.
         */
    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list, viewGroup, false);
        return new ViewHolderDatos(view);
    }

    /*
    Se encarga de establecer la comunicacion entre el adaptador y el metodo ViewHolderDatos
     */
    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {
        viewHolderDatos.asignarDatos(listaProducto.get(i));
    }

    /*
    Vamos a obtener el tamaño de la lista del adaptador.
     */
    @Override
    public int getItemCount() {
        return listaProducto.size();
    }

    /*
    Asignamos la informacion que queremos mostrar en el recyclerView
     */
    public class ViewHolderDatos extends RecyclerView.ViewHolder implements View.OnClickListener{

        TextView codigoProducto;
        TextView nombreProducto;
        ImageView papelera;
        private final Context context;

        /*
        Indicamos que datos van a ser mostrados en el recycler y asignamos la posibilidad de que sean clicables para poder pasar posteriormente a otro activity.
         */
        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            codigoProducto = (TextView) itemView.findViewById(R.id.lblCodigoProduct);
            nombreProducto = (TextView) itemView.findViewById(R.id.lblNombre);
            papelera = (ImageView) itemView.findViewById(R.id.papelera);
            context = itemView.getContext();
            itemView.setOnClickListener(this);
        }

        /*
        Asigna los datos al ViewHolder
         */
        public void asignarDatos(final Producto p) {
            codigoProducto.setText(p.getCodigoProducto());
            nombreProducto.setText(p.getNombre());
        }

        /*
        Pasamos a la activity de Modificacion/Eliminacion.
         */
        @Override
        public void onClick(View v) {
            Intent i = new Intent(context.getApplicationContext(), AddProductBD.class);
            context.startActivity(i);
        }

    }


}
