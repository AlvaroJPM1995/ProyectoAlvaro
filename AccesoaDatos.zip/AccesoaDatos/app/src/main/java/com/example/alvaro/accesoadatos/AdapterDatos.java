package com.example.alvaro.accesoadatos;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import com.example.alvaro.accesoadatos.Modelo.Producto;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos>{

    private final ArrayList<Producto> listaProducto;
    private LayoutInflater adapterInflater;

    public AdapterDatos(Context context, ArrayList<Producto> listaProducto) {
        adapterInflater = LayoutInflater.from(context);
        this.listaProducto = listaProducto;
    }

    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View mItemView = adapterInflater.inflate(R.layout.item_list, viewGroup, false);
        return new ViewHolderDatos(mItemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {
        viewHolderDatos.asignarDatos(listaProducto.get(i));
    }

    @Override
    public int getItemCount() {
        return listaProducto.size();
    }

    public class ViewHolderDatos extends RecyclerView.ViewHolder {
        public final TextView codigoProducto;
        public final TextView nombreProducto;
        public final ImageView papelera;
        final AdapterDatos adapter;

        public ViewHolderDatos(@NonNull View itemView, AdapterDatos adapter) {
            super(itemView);
            codigoProducto = itemView.findViewById(R.id.lblCodigoProduct);
            nombreProducto = itemView.findViewById(R.id.lblNombre);
            papelera = itemView.findViewById(R.id.papelera);
            this.adapter = adapter;
        }

        public void asignarDatos(final Producto p){
            codigoProducto.setText(p.getCodigoProducto());
            nombreProducto.setText(p.getNombre());
        }
    }
}
