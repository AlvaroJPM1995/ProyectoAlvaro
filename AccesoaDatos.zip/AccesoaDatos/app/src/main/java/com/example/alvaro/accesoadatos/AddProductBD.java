package com.example.alvaro.accesoadatos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.alvaro.accesoadatos.dao.CRUDBaseDatos;
import com.example.alvaro.accesoadatos.Modelo.Producto;

public class AddProductBD extends AppCompatActivity implements View.OnClickListener{

    private EditText editCodigoProducto;
    private EditText editNombreProducto;
    private EditText editDescripcionProducto;
    private EditText editFechaProducto;
    private EditText editUrlImagenProducto;
    private Button buttonAceptar;
    private String codigo;
    private String nombre;
    private String descripcion;
    private String fecha;
    private String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product_bd);

        editCodigoProducto = (EditText) findViewById(R.id.codProductoInp);
        editNombreProducto = (EditText) findViewById(R.id.nombreInp);
        editDescripcionProducto = (EditText) findViewById(R.id.descripcionInp);
        editFechaProducto = (EditText) findViewById(R.id.fechaInp);
        editUrlImagenProducto = (EditText) findViewById(R.id.urlImagenInp);
        buttonAceptar = (Button) findViewById(R.id.btnAceptar);

        buttonAceptar.setOnClickListener(this);
    }

    /*
    Se convierten todos los valores de los editText en string para poder ingresarlos posteriormente en la BD firebase.
    Llamamos al metodo addProducto.
    Realizamos un intent y nos movemos al activity main.
     */
    @Override
    public void onClick(View v) {
        codigo = editCodigoProducto.getText().toString();
        nombre = editNombreProducto.getText().toString();
        descripcion = editDescripcionProducto.getText().toString();
        fecha = editFechaProducto.getText().toString();
        url = editUrlImagenProducto.getText().toString();
        addProducto();
        Intent i = new Intent(AddProductBD.this, MainActivity.class);
        startActivity(i);
    }

    /*
    Creo un objeto de la clase Producto a la que se le añaden los valores escritos por el usuario en el activity.
    Creo un objeto de la clase CRUDBaseDatos y llamo al metodo insertarBD en el que pasamos el objeto p con todos sus valores.
     */
    public void addProducto(){
        Producto p = new Producto(codigo, nombre, descripcion, fecha, url);
        CRUDBaseDatos bd = new CRUDBaseDatos();
        bd.insertarBD(p);
    }

}
