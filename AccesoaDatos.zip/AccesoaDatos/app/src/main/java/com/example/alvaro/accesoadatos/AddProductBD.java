package com.example.alvaro.accesoadatos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import Modelo.CRUDBaseDatos;
import Modelo.Producto;

public class AddProductBD extends AppCompatActivity implements View.OnClickListener{

    private EditText editCodigoProducto;
    private EditText editNombreProducto;
    private EditText editDescripcionProducto;
    private EditText editFechaProducto;
    private EditText editUrlImagenProducto;
    private Button buttonAceptar;
    String codigo;
    String nombre;
    String descripcion;
    String fecha;
    String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product_bd);

        editCodigoProducto = (EditText) findViewById(R.id.codProductoInp);
        editNombreProducto = (EditText) findViewById(R.id.nombreInp);
        editDescripcionProducto = (EditText) findViewById(R.id.descripcionInp);
        editFechaProducto = (EditText) findViewById(R.id.fechaInp);
        editUrlImagenProducto = (EditText) findViewById(R.id.urlImagenInp);
        buttonAceptar = (Button) findViewById(R.id.btnAceptar);

        buttonAceptar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        codigo = editCodigoProducto.getText().toString();
        nombre = editNombreProducto.getText().toString();
        descripcion = editDescripcionProducto.getText().toString();
        fecha = editFechaProducto.getText().toString();
        url = editUrlImagenProducto.getText().toString();
        addProducto();
        Intent i = new Intent(AddProductBD.this, MainActivity.class);
        startActivity(i);
    }

    public void addProducto(){
        Producto p = new Producto(codigo, nombre, descripcion, fecha, url);

        CRUDBaseDatos bd = new CRUDBaseDatos();
        bd.insertarBD(p);
    }

}
