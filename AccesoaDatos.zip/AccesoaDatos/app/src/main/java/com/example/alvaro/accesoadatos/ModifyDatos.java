package com.example.alvaro.accesoadatos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class ModifyDatos extends AppCompatActivity {

    EditText editCodigoProducto;
    EditText editNombre;
    EditText editDescripcion;
    EditText editFechaAlmacenamiento;
    EditText editUrlImagen;
    Button btnModificar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);

        editCodigoProducto = (EditText) findViewById(R.id.inpCodigoProducto);
        editNombre = (EditText) findViewById(R.id.inpNombre);
        editDescripcion = (EditText) findViewById(R.id.inpDescripcion);
        editFechaAlmacenamiento = (EditText) findViewById(R.id.inpFechaAlmacenamiento);
        editUrlImagen = (EditText) findViewById(R.id.inpUrlImagen);
        btnModificar = (Button) findViewById(R.id.btnModificar);



    }
}