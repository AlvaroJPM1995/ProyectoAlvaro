package com.example.alvaro.accesoadatos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.alvaro.accesoadatos.Modelo.Producto;
import com.example.alvaro.accesoadatos.dao.CRUDBaseDatos;
import static com.example.alvaro.accesoadatos.MainActivity.listaProduct;

public class ModifyDatos extends AppCompatActivity implements View.OnClickListener{

    private TextView viewCodigoProducto;
    private EditText editNombre;
    private EditText editDescripcion;
    private EditText editFechaAlmacenamiento;
    private EditText editUrlImagen;
    private Button btnModificar;
    Producto p = new Producto();
    private String codigo;
    private String nombre;
    private String descripcion;
    private String fecha;
    private String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);

        // Asociamos los EditText y TextView creados con los campos de texto del layout.
        viewCodigoProducto = (TextView) findViewById(R.id.inpCodigoProducto);
        editNombre = (EditText) findViewById(R.id.inpNombre);
        editDescripcion = (EditText) findViewById(R.id.inpDescripcion);
        editFechaAlmacenamiento = (EditText) findViewById(R.id.inpFechaAlmacenamiento);
        editUrlImagen = (EditText) findViewById(R.id.inpUrlImagen);
        btnModificar = (Button) findViewById(R.id.btnModificar);

        // Recibimos el objeto del AdapterDatos con todos sus datos sobre el que hemos pulsado.
        p = (Producto) getIntent().getExtras().getSerializable("modificacion");

        // Asignamos los datos del objeto que hemos recibido del adapter y los mostramos en los campos creados anteriormente.
        viewCodigoProducto.setText(p.getCodigoProducto());
        editNombre.setText(p.getNombre());
        editDescripcion.setText(p.getDescripcion());
        editFechaAlmacenamiento.setText(p.getFechaAlmacenamiento());
        editUrlImagen.setText(p.getUrlImagen());

        btnModificar.setOnClickListener(this);
    }

    // Metemos los datos que hemos modificado en el layout en unas strings.
    @Override
    public void onClick(View v) {
        //CRUDBaseDatos modificacion = new CRUDBaseDatos();
        //modificacion.actualizarBD(p);
        codigo = viewCodigoProducto.getText().toString();
        nombre = editNombre.getText().toString();
        descripcion = editDescripcion.getText().toString();
        fecha = editFechaAlmacenamiento.getText().toString();
        url = editUrlImagen.getText().toString();
        // Llamamos al metodo modificar producto desde el que vamos a contactar con la clase CRUD para modificar los datos en la BD.
        modificarProducto();
        // Creamos el intent con el que nos vamos a mover a la MainActivity.
        Intent i = new Intent(ModifyDatos.this, MainActivity.class);
        startActivity(i);
    }

    // Creamos un objeto de la clase producto a la que le metemos los datos modificados ya siendo string.
    public void modificarProducto(){
        Producto a = new Producto(codigo, nombre, descripcion, fecha, url);
        // Creamos un objeto de la clase CRUD y llamamos al metodo actualizarBD al que le pasamos el objeto anteriormente creado de la clase Producto.
        CRUDBaseDatos bd = new CRUDBaseDatos();
        bd.actualizarBD(a);
    }
}