package com.example.alvaro.accesoadatos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.alvaro.accesoadatos.Modelo.Producto;
import com.example.alvaro.accesoadatos.dao.CRUDBaseDatos;
import static com.example.alvaro.accesoadatos.MainActivity.listaProduct;

public class ModifyDatos extends AppCompatActivity implements View.OnClickListener{

    private TextView viewCodigoProducto;
    private EditText editNombre;
    private EditText editDescripcion;
    private EditText editFechaAlmacenamiento;
    private EditText editUrlImagen;
    private Button btnModificar;
    Producto p = new Producto();
    private String codigo;
    private String nombre;
    private String descripcion;
    private String fecha;
    private String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify);

        viewCodigoProducto = (TextView) findViewById(R.id.inpCodigoProducto);
        editNombre = (EditText) findViewById(R.id.inpNombre);
        editDescripcion = (EditText) findViewById(R.id.inpDescripcion);
        editFechaAlmacenamiento = (EditText) findViewById(R.id.inpFechaAlmacenamiento);
        editUrlImagen = (EditText) findViewById(R.id.inpUrlImagen);
        btnModificar = (Button) findViewById(R.id.btnModificar);

        p = (Producto) getIntent().getExtras().getSerializable("modificacion");

        viewCodigoProducto.setText(p.getCodigoProducto());
        editNombre.setText(p.getNombre());
        editDescripcion.setText(p.getDescripcion());
        editFechaAlmacenamiento.setText(p.getFechaAlmacenamiento());
        editUrlImagen.setText(p.getUrlImagen());

        btnModificar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        //CRUDBaseDatos modificacion = new CRUDBaseDatos();
        //modificacion.actualizarBD(p);
        codigo = viewCodigoProducto.getText().toString();
        nombre = editNombre.getText().toString();
        descripcion = editDescripcion.getText().toString();
        fecha = editFechaAlmacenamiento.getText().toString();
        url = editUrlImagen.getText().toString();
        modificarProducto();
        Intent i = new Intent(ModifyDatos.this, MainActivity.class);
        startActivity(i);
    }

    public void modificarProducto(){
        Producto a = new Producto(codigo, nombre, descripcion, fecha, url);
        CRUDBaseDatos bd = new CRUDBaseDatos();
        bd.actualizarBD(a);
    }
}