package com.example.alvaro.accesoadatos.Idao;

import com.example.alvaro.accesoadatos.Modelo.Producto;

public interface IProductoDAO {
    public void insertarBD(Producto p);
    public void leerBD();
    public void actualizarBD();
    public void borrarBD();
}
