package com.example.alvaro.accesoadatos;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import Modelo.Producto;

public class MainActivity extends AppCompatActivity{

    Button addProduct;

    DatabaseReference databaseReference;

    AdapterDatos adapter;
    List<Producto> listaProducto = new ArrayList<>();
    RecyclerView recycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addProduct = (Button) findViewById(R.id.addProduct);

        addProduct.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, AddProductBD.class);
                startActivity(i);
            }
        });

        /*mostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CRUDBaseDatos lectura = new CRUDBaseDatos();

                Producto producto = lectura.leerBD();
                prueba.setText(producto.getCodigoProducto());


            }
        });*/

        recycler = findViewById(R.id.recyclerId);
        recycler.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));

        listaProducto = new ArrayList<Producto>();

        /*for (int i = 0; i < 10; i++) {
            listDatos.add("Dato # "+i+ " ");
        }*/

        mostrarDatos();

        AdapterDatos adapter = new AdapterDatos(listaProducto);
        recycler.setAdapter(adapter);


    }

    public void mostrarDatos(){
        databaseReference.child("Productos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listaProducto.clear();
                for(DataSnapshot objSnapchot : dataSnapshot.getChildren()){
                    Producto p = objSnapchot.getValue(Producto.class);
                    listaProducto.add(p);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
