package com.example.alvaro.accesoadatos;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import com.example.alvaro.accesoadatos.Modelo.Producto;

public class MainActivity extends AppCompatActivity{

    Button addProduct;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    private AdapterDatos adapter;
    private RecyclerView recycler;
    private static ArrayList<Producto> listaProduct = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addProduct = findViewById(R.id.addProduct);
        addProduct.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, AddProductBD.class);
                startActivity(i);
            }
        });

        recycler = findViewById(R.id.recyclerId);
        adapter = new AdapterDatos(this, listaProduct);
        recycler.setAdapter(adapter);
        recycler.setLayoutManager(new LinearLayoutManager(this));

        for (int i = 0; i < listaProduct.size(); i++) {
            mostrarDatos();
        }


        //mostrarDatos();
    }

    public void mostrarDatos(){
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Productos");
        databaseReference.child("Productos").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                listaProduct.clear();
                for(DataSnapshot objSnapchot : dataSnapshot.getChildren()){
                    Producto p = objSnapchot.getValue(Producto.class);
                    listaProduct.add(p);

                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }


}
