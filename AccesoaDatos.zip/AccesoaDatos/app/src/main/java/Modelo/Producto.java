package Modelo;

public class Producto {

    private String codigoProducto;
    private String nombre;
    private String descripcion;
    private String fechaAlmacenamiento;
    private String urlImagen;

    public Producto (String codigoProducto, String nombre, String descripcion, String fechaAlmacenamiento, String urlImagen){
        this.codigoProducto = codigoProducto;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.fechaAlmacenamiento = fechaAlmacenamiento;
        this.urlImagen = urlImagen;
    }

    public String getCodigoProducto() {
        return codigoProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getFechaAlmacenamiento() {
        return fechaAlmacenamiento;
    }

    public String getUrlImagen() {
        return urlImagen;
    }

    public void setCodigoProducto(String codigoProducto) {
        this.codigoProducto = codigoProducto;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setFechaAlmacenamiento(String fechaAlmacenamiento) {
        this.fechaAlmacenamiento = fechaAlmacenamiento;
    }

    public void setUrlImagen(String urlImagen) {
        this.urlImagen = urlImagen;
    }
}
