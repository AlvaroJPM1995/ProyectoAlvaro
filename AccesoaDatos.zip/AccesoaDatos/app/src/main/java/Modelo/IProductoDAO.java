package Modelo;

import android.widget.TextView;

public interface IProductoDAO {
    public void insertarBD(Producto p);
    public Producto leerBD();
    public void actualizarBD();
    public void borrarBD();
}
