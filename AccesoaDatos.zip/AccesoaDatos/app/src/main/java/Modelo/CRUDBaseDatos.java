package Modelo;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CRUDBaseDatos implements IProductoDAO {

    DatabaseReference databaseReference;


    public void insertarBD(Producto p){
        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseReference.child("Productos").child("1").setValue(p);
    }

    public Producto leerBD(){
        final Producto producto = null;
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Productos").child(String.valueOf("1"));
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Producto prod = (Producto) dataSnapshot.getValue();
                producto.setCodigoProducto(prod.getCodigoProducto());
                producto.setNombre(prod.getNombre());
                producto.setDescripcion(prod.getDescripcion());
                producto.setFechaAlmacenamiento(prod.getFechaAlmacenamiento());
                producto.setUrlImagen(prod.getUrlImagen());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return producto;

    }

    public void actualizarBD(){

    }

    public void borrarBD(){

    }

}