package com.example.alvaro.aplicaciontrimestre;

public class Preguntas {

    /*En esta clase me encargo de crear las variables que voy a usar para coger las preguntas y las repuestas de la base de datos y que luego utilizaré en cada
    clase de preguntas haciendo referencia a esta misma.
    */
    public String question,opcion1,opcion2,opcion3,pregunta,respuesta;

    public Preguntas(String question, String opcion1, String opcion2, String opcion3, String pregunta, String respuesta) {
        this.question = question;
        this.opcion1 = opcion1;
        this.opcion2 = opcion2;
        this.opcion3 = opcion3;
        this.pregunta = pregunta;
        this.respuesta = respuesta;
    }

    public Preguntas(){}

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getOpcion1() {
        return opcion1;
    }

    public void setOpcion1(String opcion1) {
        this.opcion1 = opcion1;
    }

    public String getOpcion2() {
        return opcion2;
    }

    public void setOpcion2(String opcion2) {
        this.opcion2 = opcion2;
    }

    public String getOpcion3() {
        return opcion3;
    }

    public void setOpcion3(String opcion3) {
        this.opcion3 = opcion3;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }
}
