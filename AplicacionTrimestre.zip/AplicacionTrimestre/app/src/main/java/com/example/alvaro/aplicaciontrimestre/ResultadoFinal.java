package com.example.alvaro.aplicaciontrimestre;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ResultadoFinal extends AppCompatActivity {

    TextView contadorTotales;
    TextView contadorCorrectas;
    TextView contadorIncorrectas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resultado_final);

        contadorTotales = (TextView) findViewById(R.id.contadorTotales);
        contadorCorrectas = (TextView) findViewById(R.id.preguntasIncorrectas);
        contadorIncorrectas = (TextView) findViewById(R.id.contadorIncorrectas);

        Intent i = getIntent();

        String totales  = i.getStringExtra("total");
        String correctas = i.getStringExtra("correctas");
        String incorrectas = i.getStringExtra("incorrectas");

        contadorTotales.setText(totales);
        contadorCorrectas.setText(correctas);
        contadorIncorrectas.setText(incorrectas);

    }

}
