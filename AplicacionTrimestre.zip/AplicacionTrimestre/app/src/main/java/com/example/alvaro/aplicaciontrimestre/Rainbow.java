package com.example.alvaro.aplicaciontrimestre;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Rainbow extends AppCompatActivity {

    Button boton1;
    Button boton2;
    Button boton3;
    TextView question;

    double puntuacion = 0;
    int total = 0;
    int correctas = 0;
    int incorrectas = 0;

    DatabaseReference reference;

    //Creo unn MediaPlayer que me va a servir para añadir musica a las activities mientras juegas a un juego específico.
    MediaPlayer musica;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preguntas_rainbow);

        boton1 = (Button) findViewById(R.id.respuesta1);
        boton2 = (Button) findViewById(R.id.respuesta2);
        boton3 = (Button) findViewById(R.id.respuesta3);
        question = (TextView) findViewById(R.id.textoPregunta);

        //Indico que musica ha de añadir en esta activity y comienzo su reproducción
        musica = MediaPlayer.create(this, R.raw.rainbow);
        musica.start();

        actualizarPregunta();

    }

    private void actualizarPregunta() {

        total++;

        if (total > 8) {
            //Abrimos la activity resultado. y pasamos los datos: preguntas correctas, preguntas incorrectas, preguntas totales y la puntuación obtenida.
            Intent i = new Intent(Rainbow.this, ResultadoFinal.class);
            i.putExtra("total", String.valueOf(total));
            i.putExtra("correctas", String.valueOf(correctas));
            i.putExtra("incorrectas", String.valueOf(incorrectas));
            i.putExtra("puntuacion", String.valueOf(puntuacion));
            //Antes de pasar a la siguiente activity paro la reproducción de la música.
            musica.stop();
            startActivity(i);

        } else {

            //hacemos referencia en nuestra base de datos a que queremos exactamente llamar.
            reference = FirebaseDatabase.getInstance().getReference().child("Preguntas Rainbow").child(String.valueOf(total));
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    //creamos el objeto de la clase Preguntas e indicamos que queremos meter en los botones los textos correspondientes a la pregunta y las posibles respuestas.
                    final Preguntas preguntas = dataSnapshot.getValue(Preguntas.class);

                    question.setText(preguntas.getPregunta());
                    boton1.setText(preguntas.getOpcion1());
                    boton2.setText(preguntas.getOpcion2());
                    boton3.setText(preguntas.getOpcion3());


                    boton1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //Comprueba al pulsar el boton1 si esta es la respuesta correcta, en caso de serlo lo coloca de color verde.
                            if (boton1.getText().toString().equals(preguntas.getRespuesta())) {

                                Toast.makeText(Rainbow.this, "¡Respuesta Correcta!", Toast.LENGTH_SHORT).show();

                                boton1.setBackgroundColor(Color.GREEN);

                                correctas = correctas + 1;
                                puntuacion = puntuacion + 1.25;

                                //El handler es como un thread.
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {

                                        //Devolvemos al boton con el color modificado el color que tenia en un principio y comenzamos la siguiente pregunta.
                                        boton1.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        actualizarPregunta();

                                    }
                                }, 1500);
                            } else {

                                Toast.makeText(Rainbow.this, "¡Respuesta Incorrecta!", Toast.LENGTH_SHORT).show();

                                incorrectas = incorrectas + 1;
                                puntuacion = puntuacion - 0.5;

                                //Habiendo fallado la respuesta nos pondrá la que hemos marcado de color rojo y nos indicará cual es la respuesta correcta poniendola de color verde.
                                boton1.setBackgroundColor(Color.RED);

                                if (boton2.getText().toString().equals(preguntas.getRespuesta())) {
                                    boton2.setBackgroundColor(Color.GREEN);
                                } else if (boton3.getText().toString().equals(preguntas.getRespuesta())) {
                                    boton3.setBackgroundColor(Color.GREEN);
                                }

                                //Devolvemos a cualquier boton su color original antes de comenzar la siguiente pregunta e iniciamos posteriormente la siguiente pregunta.
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        boton1.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        boton2.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        boton3.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        actualizarPregunta();
                                    }
                                }, 1500);

                            }
                        }
                    });

                    //Repetimos la accion realizada anteriormente pero ahora con el boton 2.
                    boton2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //Comprueba al pulsar el boton2 si esta es la respuesta correcta, en caso de serlo lo coloca de color verde.
                            if (boton2.getText().toString().equals(preguntas.getRespuesta())) {

                                Toast.makeText(Rainbow.this, "¡Respuesta Correcta!", Toast.LENGTH_SHORT).show();

                                boton2.setBackgroundColor(Color.GREEN);

                                correctas = correctas + 1;
                                puntuacion = puntuacion + 1.25;

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {

                                        //Devolvemos al boton con el color modificado el color que tenia en un principio y comenzamos la siguiente pregunta.
                                        boton2.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        actualizarPregunta();

                                    }
                                }, 1500);
                            } else {

                                Toast.makeText(Rainbow.this, "¡Respuesta Incorrecta!", Toast.LENGTH_SHORT).show();

                                incorrectas = incorrectas + 1;
                                puntuacion = puntuacion - 0.5;

                                //Habiendo fallado la respuesta nos pondrá la que hemos marcado de color rojo y nos indicará cual es la respuesta correcta poniendola de color verde.
                                boton2.setBackgroundColor(Color.RED);

                                if (boton1.getText().toString().equals(preguntas.getRespuesta())) {
                                    boton1.setBackgroundColor(Color.GREEN);
                                } else if (boton3.getText().toString().equals(preguntas.getRespuesta())) {
                                    boton3.setBackgroundColor(Color.GREEN);
                                }

                                //Devolvemos a cualquier boton su color original antes de comenzar la siguiente pregunta e iniciamos posteriormente la siguiente pregunta.
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        boton1.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        boton2.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        boton3.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        actualizarPregunta();
                                    }
                                }, 1500);

                            }
                        }
                    });

                    //Volvemos a repetir de nuevo la misma accion pero ahora con el tercer botón.
                    boton3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //Comprueba al pulsar el boton1 si esta es la respuesta correcta, en caso de serlo lo coloca de color verde.
                            if (boton3.getText().toString().equals(preguntas.getRespuesta())) {

                                Toast.makeText(Rainbow.this, "¡Respuesta Correcta!", Toast.LENGTH_SHORT).show();

                                boton3.setBackgroundColor(Color.GREEN);

                                correctas = correctas + 1;
                                puntuacion = puntuacion + 1.25;

                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {

                                        //Devolvemos al boton con el color modificado el color que tenia en un principio y comenzamos la siguiente pregunta.
                                        boton3.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        actualizarPregunta();

                                    }
                                }, 1500);
                            } else {

                                Toast.makeText(Rainbow.this, "¡Respuesta Incorrecta!", Toast.LENGTH_SHORT).show();

                                incorrectas = incorrectas + 1;
                                puntuacion = puntuacion - 0.5;

                                //Habiendo fallado la respuesta nos pondrá la que hemos marcado de color rojo y nos indicará cual es la respuesta correcta poniendola de color verde.
                                boton3.setBackgroundColor(Color.RED);

                                if (boton2.getText().toString().equals(preguntas.getRespuesta())) {
                                    boton2.setBackgroundColor(Color.GREEN);
                                } else if (boton1.getText().toString().equals(preguntas.getRespuesta())) {
                                    boton1.setBackgroundColor(Color.GREEN);
                                }

                                //Devolvemos a cualquier boton su color original antes de comenzar la siguiente pregunta e iniciamos posteriormente la siguiente pregunta.
                                Handler handler = new Handler();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        boton1.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        boton2.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        boton3.setBackgroundColor(Color.parseColor("#DCDCDC"));
                                        actualizarPregunta();
                                    }
                                }, 1500);

                            }
                        }
                    });

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
    }
}