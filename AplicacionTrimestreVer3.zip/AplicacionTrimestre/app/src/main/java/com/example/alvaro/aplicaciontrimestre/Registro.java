package com.example.alvaro.aplicaciontrimestre;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


import com.google.firebase.auth.FirebaseAuth;

import org.w3c.dom.Text;
public class Registro extends AppCompatActivity implements View.OnClickListener {

    //Declaración de todas las variables.
    Button finalizar;
    EditText emailusuario;
    EditText contraseñaUsuario;
    Button botonatras;

    //Declaramos el autenticador de firebase
    FirebaseAuth.AuthStateListener mAuthListener;

    //Se crean todos los botones y cuadros de texto.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        finalizar = (Button) findViewById(R.id.botonFinalizar);
        emailusuario = (EditText) findViewById(R.id.editEmail);
        contraseñaUsuario = (EditText) findViewById(R.id.editContraseña);
        botonatras = (Button) findViewById(R.id.botonatras);

        botonatras.setOnClickListener(this);
        finalizar.setOnClickListener(this);


        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();

            }
        };
    }

    //Creo la funcion que llamará a la base de datos para ingresar los textos escritos en los campos de registro.
    private void finalizar(String email, String contraseña) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, contraseña).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    Toast.makeText(Registro.this, "El usuario se ha creado", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(Registro.this, MainActivity.class);
                    startActivity(i);
                } else {
                    Toast.makeText(Registro.this, "Fallo en el registro", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    //Funcion encargada de volver a la anterior activity.
    public void atras() {
        Intent i = new Intent(Registro.this, MainActivity.class);
        startActivity(i);
    }

    //Metodo encargado de asignar funciones a los botones.
    @Override
    public void onClick(View view) {
        String email = emailusuario.getText().toString();
        String contraseña = contraseñaUsuario.getText().toString();

        switch (view.getId()) {
            case R.id.botonatras:
                atras();
                break;
            case R.id.botonFinalizar:
                finalizar(email, contraseña);
                break;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseAuth.getInstance().addAuthStateListener(mAuthListener);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(mAuthListener!=null){
            FirebaseAuth.getInstance().removeAuthStateListener(mAuthListener);
        }
    }
}