package com.example.alvaro.aplicaciontrimestre;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;


public class ResultadoFinal extends AppCompatActivity {

    TextView contadorTotales;
    TextView contadorCorrectas;
    TextView contadorIncorrectas;
    TextView puntuacionTotal;
    TextView frase;
    Button categoria;
    double puntuacionFinal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resultado_final);

        contadorTotales = (TextView) findViewById(R.id.contadorTotales);
        contadorCorrectas = (TextView) findViewById(R.id.contadorCorrectas);
        contadorIncorrectas = (TextView) findViewById(R.id.contadorIncorrectas);
        puntuacionTotal = (TextView) findViewById(R.id.contadorPuntuacion);
        categoria = (Button) findViewById(R.id.categorias);
        frase = (TextView) findViewById(R.id.fraseFinal);

        Intent i = getIntent();

        String totales  = i.getStringExtra("total");
        String correctas = i.getStringExtra("correctas");
        String incorrectas = i.getStringExtra("incorrectas");
        String puntuacion = i.getStringExtra("puntuacion");

        contadorTotales.setText(totales);
        contadorCorrectas.setText(correctas);
        contadorIncorrectas.setText(incorrectas);
        puntuacionTotal.setText(puntuacion);

        puntuacionFinal = Double.parseDouble(puntuacion);

        TextoFinal(puntuacionFinal);

        categoria.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ResultadoFinal.this, Categorias.class);
                startActivity(i);
            }
        });

    }

    public void TextoFinal(double puntuacionFinal){

        String frase1 = "Se nota que nunca has jugado a este juego";
        String frase2 = "Eres un jugador casual que prefiere divertirse ";
        String frase3 = "Empiezas a interesarte por el juego";
        String frase4 = "Dominas el juego, pero aun te queda un poco que aprender";
        String frase5 = "Eres un viciado y conoces mejor al juego que a tu familia";

        if(puntuacionFinal <= 0 ){

            frase.setText(frase1);

        } else if (puntuacionFinal > 0 && puntuacionFinal < 5) {

            frase.setText(frase2);

        } else if (puntuacionFinal == 5) {

            frase.setText(frase3);

        } else if (puntuacionFinal > 5 && puntuacionFinal < 10) {

            frase.setText(frase4);

        } else if (puntuacionFinal == 10) {

            frase.setText(frase5);

        }

    }

}
