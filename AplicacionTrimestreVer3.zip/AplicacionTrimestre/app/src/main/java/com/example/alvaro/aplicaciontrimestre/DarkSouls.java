package com.example.alvaro.aplicaciontrimestre;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DarkSouls extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dark_souls);
    }
}
