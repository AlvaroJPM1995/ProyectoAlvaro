package com.example.alvaro.aplicaciontrimestre;

/**
 * The type Preguntas.
 */
public class Preguntas {

    /**
     * The Question.
     */
    /*En esta clase me encargo de crear las variables que voy a usar para coger las preguntas y las repuestas de la base de datos y que luego utilizaré en cada
    clase de preguntas haciendo referencia a esta misma.*/
    public String question, /**
     * The Opcion 1.
     */
    opcion1, /**
     * The Opcion 2.
     */
    opcion2, /**
     * The Opcion 3.
     */
    opcion3, /**
     * The Pregunta.
     */
    pregunta, /**
     * The Respuesta.
     */
    respuesta;

    /**
     * Instantiates a new Preguntas.
     *
     * @param question  the question
     * @param opcion1   the opcion 1
     * @param opcion2   the opcion 2
     * @param opcion3   the opcion 3
     * @param pregunta  the pregunta
     * @param respuesta the respuesta
     */
    public Preguntas(String question, String opcion1, String opcion2, String opcion3, String pregunta, String respuesta) {
        this.question = question;
        this.opcion1 = opcion1;
        this.opcion2 = opcion2;
        this.opcion3 = opcion3;
        this.pregunta = pregunta;
        this.respuesta = respuesta;
    }

    /**
     * Instantiates a new Preguntas.
     */
    public Preguntas(){}

    /**
     * Gets question.
     *
     * @return the question
     */
    public String getQuestion() {
        return question;
    }

    /**
     * Sets question.
     *
     * @param question the question
     */
    public void setQuestion(String question) {
        this.question = question;
    }

    /**
     * Gets opcion 1.
     *
     * @return the opcion 1
     */
    public String getOpcion1() {
        return opcion1;
    }

    /**
     * Sets opcion 1.
     *
     * @param opcion1 the opcion 1
     */
    public void setOpcion1(String opcion1) {
        this.opcion1 = opcion1;
    }

    /**
     * Gets opcion 2.
     *
     * @return the opcion 2
     */
    public String getOpcion2() {
        return opcion2;
    }

    /**
     * Sets opcion 2.
     *
     * @param opcion2 the opcion 2
     */
    public void setOpcion2(String opcion2) {
        this.opcion2 = opcion2;
    }

    /**
     * Gets opcion 3.
     *
     * @return the opcion 3
     */
    public String getOpcion3() {
        return opcion3;
    }

    /**
     * Sets opcion 3.
     *
     * @param opcion3 the opcion 3
     */
    public void setOpcion3(String opcion3) {
        this.opcion3 = opcion3;
    }

    /**
     * Gets pregunta.
     *
     * @return the pregunta
     */
    public String getPregunta() {
        return pregunta;
    }

    /**
     * Sets pregunta.
     *
     * @param pregunta the pregunta
     */
    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    /**
     * Gets respuesta.
     *
     * @return the respuesta
     */
    public String getRespuesta() {
        return respuesta;
    }

    /**
     * Sets respuesta.
     *
     * @param respuesta the respuesta
     */
    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }
}
