package com.example.alvaro.aplicaciontrimestre;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

/**
 * The type Categorias.
 */
public class Categorias extends AppCompatActivity implements View.OnClickListener {

    /**
     * The Rainbow six.
     */
    Button rainbowSix;
    /**
     * The Dark souls.
     */
    Button darkSouls;

    /**
     * Creacion de los botones y sus acciones al pulsarlo.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorias);

        rainbowSix = (Button) findViewById(R.id.rainbowBanner);
        darkSouls = (Button) findViewById(R.id.darkSoulsBanner);

        rainbowSix.setOnClickListener(this);
        darkSouls.setOnClickListener(this);

    }

    /**
     * Según el boton(banner) que se pulse nos mandará a una activity de preguntas u a otra
     */
    public void onClick(View view){

        switch (view.getId()) {
            case R.id.rainbowBanner:
                Intent r = new Intent(Categorias.this, Rainbow.class);
                startActivity(r);
                break;
            case R.id.darkSoulsBanner:
                Intent d = new Intent(Categorias.this, DarkSouls.class);
                startActivity(d);
                break;
        }

    }
}
