package com.example.alvaro.aplicaciontrimestre;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    //Declaracion de las variables.
    Button entrar;
    Button registrarse;
    EditText mail_usuario;
    EditText contraseña_usuario;

    //Se crean los botones y los cuadros de texto.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Esta primera linea sirve para elimiar la barra superior de la aplicación que sale con el nombre de la misma.
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        entrar = (Button) findViewById(R.id.botonEntrar);
        mail_usuario = (EditText) findViewById(R.id.botonEmail);
        contraseña_usuario = (EditText) findViewById(R.id.passwdText);
        registrarse = (Button) findViewById(R.id.botonRegistrarse);


        entrar.setOnClickListener(this);
        registrarse.setOnClickListener(this);

    }

    //Llama a la base de datos, consulta si los datos ingresados en los cuadros de texto coinciden con datos guardados y da paso a la siguiente activity en caso afirmativo.
    private void iniciarSesion(String email, String pass){
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Sesión iniciada correctamente", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(MainActivity.this, Rainbow.class);
                    startActivity(i);
                }else{
                    Toast.makeText(MainActivity.this, "Datos erroneos", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    //Se agregan las funciones pertinentes a cada boton.
    @Override
    public void onClick(View view) {
        String email = mail_usuario.getText().toString();
        String contraseña = contraseña_usuario.getText().toString();

        switch (view.getId()) {
            case R.id.botonEntrar:
                iniciarSesion(email,contraseña);
                break;
            case R.id.botonRegistrarse:
                iniciarRegistro();
                break;
        }
    }

    //Metodo para ir al activity de registro.
    public void iniciarRegistro(){

        Intent i = new Intent(MainActivity.this, Registro.class);
        startActivity(i);
    }

}
