package com.example.alvaro.myapplication;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;
import android.view.View;

public class SQLiteBD extends SQLiteOpenHelper {

    //Creamos la sentencia que creará la tabla.
    String sql = "CREATE TABLE Usuario (Nombre TEXT, Apellidos TEXT, Email TEXT PRIMARY KEY, Contrasena TEXT);";

    public SQLiteBD(Context context, String name) {
        super( context, name, null, 1);
    }

    @Override //Con la primera llamada a la clase se usará este metodo que es el encargado de crear la base de datos.
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(sql);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Usuario");
        db.execSQL(sql);
    }
}
