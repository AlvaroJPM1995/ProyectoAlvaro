package com.example.alvaro.myapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    Button entrar;
    Button registrarse;
    EditText mail_usuario;
    EditText contraseña;
    TextView textoprueba;

    String mail = "prueba";
    String passwd = "prueba";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        entrar = (Button) findViewById(R.id.botonEntrar);
        mail_usuario = (EditText) findViewById(R.id.botonEmail);
        contraseña = (EditText) findViewById(R.id.passwdText);
        registrarse = (Button) findViewById(R.id.botonRegistrarse);
        //textoprueba = (TextView) findViewById(R.id.textoprueba);

        entrar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if(mail_usuario.getText().toString().equals(mail) && contraseña.getText().toString().equals(passwd)){

                    Intent i = new Intent(MainActivity.this, TresActivity.class);
                    startActivity(i);

                }else{

                    //textoprueba.setText("Contraseña o Mail incorrecto");
                    Toast.makeText(MainActivity.this, "Mail o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                }

            }
        });

        registrarse.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this, DosActivity.class);
                startActivity(i);

            }
        });
    }

    public void comprobar(){
        SQLiteBD usuario = new SQLiteBD(this, "BDUsuario");
        SQLiteDatabase bd = usuario.getWritableDatabase();
        String usuariologin = mail_usuario.getText().toString();
        String passwdlogin = contraseña.getText().toString();

    }

}
