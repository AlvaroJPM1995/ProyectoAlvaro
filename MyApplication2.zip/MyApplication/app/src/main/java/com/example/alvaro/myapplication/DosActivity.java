package com.example.alvaro.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class DosActivity extends AppCompatActivity {

    Button finalizar;
    EditText nombreUsuario;
    EditText apellidosUsuario;
    EditText emailUsuario;
    EditText contraseñaUsuario;
    String nombre;
    String apellidos;
    String email;
    String contraseña;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dos);

        finalizar = (Button) findViewById(R.id.botonFinalizar);
        nombreUsuario = (EditText) findViewById(R.id.editNombre);
        apellidosUsuario = (EditText) findViewById(R.id.editApellidos);
        emailUsuario = (EditText) findViewById(R.id.editEmail);
        contraseñaUsuario = (EditText) findViewById(R.id.editContraseña);

    }

    //Este metodo realiza la Inserción de datos en la BD
    public void insertarEnBD(View v){
        nombre = nombreUsuario.getText().toString();
        apellidos = apellidosUsuario.getText().toString();
        email = emailUsuario.getText().toString();
        contraseña = contraseñaUsuario.getText().toString();


            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    SQLiteBD usuario = new SQLiteBD(getApplicationContext(), "BDUsuario");
                    SQLiteDatabase db = usuario.getReadableDatabase();

                    //Comprobamos si todos los campos tienen datos escritos
                    if(nombre.length() > 0 && apellidos.length() > 0 && email.length() > 0 && contraseña.length() > 0) {
                        String cadena = "SELECT Email FROM Usuario";
                        Cursor comprobar = db.rawQuery(cadena, null);



                        comprobar.moveToLast();
                        comprobar.getString(1);
                        while (comprobar.moveToNext()) {
                            System.out.println("Entra aqui");
                            comprobar.getString(1);
                        }
                        comprobar.close();

                    }
                else{
                    Toast.makeText(DosActivity.this, "Debes rellenar todos los parametros", Toast.LENGTH_SHORT).show();
                }

            }
        });
            t.start();
    }
}
